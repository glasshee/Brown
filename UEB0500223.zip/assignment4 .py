# REE 200 & PET ENG 200 - Assignment 2
# Author: Hygenius Mensah Agyapong
# Description: Solutions to Python string and math tasks
# -------------------------------------------------------

import string
import math

# Task 1 - Convert all uppercase letters to lowercase
def convert_to_lowercase(s):
    """
    Converts all characters in the string to lowercase.
    """
    return s.lower()


# Task 2 - Swap uppercase to lowercase and vice versa
def swap_case(s):
    """
    Swaps case of each character in the string.
    """
    return s.swapcase()


# Task 3 - Remove all uppercase letters
def remove_uppercase(s):
    """
    Removes all uppercase letters from the string.
    """
    return ''.join(char for char in s if not char.isupper())


# Task 4 - Count uppercase and lowercase letters
def count_case(s):
    """
    Counts uppercase and lowercase letters.
    Returns a formatted string.
    """
    upper = sum(1 for char in s if char.isupper())
    lower = sum(1 for char in s if char.islower())
    return f"Uppercase: {upper}, Lowercase: {lower}"


# Task 5 - Remove all non-English letters
def remove_non_alpha(s):
    """
    Removes digits, punctuation, and non-letter characters.
    """
    return ''.join(char for char in s if char.isalpha())


# Task 6 - Compute triangle area using Heron's formula
def triangle_area(a, b, c):
    """
    Computes the area of a triangle using Heron's formula.
    """
    s = (a + b + c) / 2
    area = math.sqrt(s * (s - a) * (s - b) * (s - c))
    return round(area, 2)


# Task 7 - Neatly format names in a table
def print_name_table(names):
    """
    Displays names centered in a formatted table.
    """
    print("Name List".center(30, "="))
    for name in names:
        print(name.center(30))
    print("=" * 30)


# Task 8 - Clean string: strip spaces, remove punctuation, remove inner spaces
def clean_string(s):
    """
    Cleans the string by removing:
    - leading/trailing spaces
    - punctuation
    - all spaces
    """
    s = s.strip()
    s = ''.join(char for char in s if char not in string.punctuation)
    s = s.replace(" ", "")
    return s


# ------------------ TEST CASES ------------------

print("TASK 1:", convert_to_lowercase("Hello"))             # Output: "hello"
print("TASK 2:", swap_case("HeLLo WoRLd"))                  # Output: "hEllO wOrlD"
print("TASK 3:", remove_uppercase("HelloWorld"))            # Output: "elloorld"
print("TASK 4:", count_case("EngiNEEr"))                    # Output: Uppercase: 4, Lowercase: 4
print("TASK 5:", remove_non_alpha("Data-Driven@2025!"))     # Output: "DataDriven"
print("TASK 6: Area =", triangle_area(3, 4, 5))             # Output: 6.0
print("\nTASK 7:")
print_name_table(["Alice", "Bob", "Cynthia", "David"])      # Prints a neat table
print("TASK 8:", clean_string("   Hello, World!    "))      # Output: "HelloWorld"
