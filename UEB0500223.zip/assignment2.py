#Task 1
import math
import string


H = input(str("Enter any UpperCase: "))
print(H.lower())


#TASK 2
H = input(str("Enter any mixed case: "))
x = H.swapcase()
print(x)

# TASK 3
s = input(str("Enter any mixedCase: "))
x = ''.join(ch for ch in s if not ch.isupper())
print(x)


#TASK 4
s = input(str("Enter any MixedCase:"))
K = sum(1 for ch in s if ch.isupper())
Y = sum(1 for ch in s if ch.islower())
print("UpperCase:", K, "LowerCase:", Y )


#TASK 5
s = input(str("Enter any caseletter including symbols:"))
x = ''.join(ch for ch in s if ch.isalpha())
print(x)

#TASK 6
c = input("Enter a number:")
a = input("Enter a number:")
t = input("Enter a number:")
p = c + a + t 
s = (p) / 2
x = math.sqrt(s * (s-c) * (s-a) * (s-t)) 
print(x)

#TASK 7
s = input(int("How many names?"))
x = []
for _ in range(s):
    y = input("Enter a name: ")
    x.append(y)
print("\nFormatted Table: ")
for y in x:
    print(y.ljust(12), y.center(12), y.rjust(12))

#Task 8
S = input(str('Enter any word with puntuations'))
s = S.strip()
s="".join(ch for ch in s if ch not in string.puntuation)
s = s. replace("", "")
print (s)

