class PetroleumFormula:
    """Base class for petroleum formulas"""
    def calculate(self):
        raise NotImplementedError("Subclass must implement calculate method")

# 1. Ideal Gas Law: PV = nRT
class IdealGasLaw(PetroleumFormula):
    def __init__(self, P, V, n, R=0.0821, T=None):
        self.P = P
        self.V = V
        self.n = n
        self.R = R
        self.T = T

    def calculate(self):
        try:
            if self.T is None:
                self.T = (self.P * self.V) / (self.n * self.R)
            return self.T
        except Exception as e:
            return f"Error: {e}"

# 2. Density = Mass / Volume
class Density(PetroleumFormula):
    def __init__(self, mass, volume):
        self.mass = mass
        self.volume = volume

    def calculate(self):
        try:
            return self.mass / self.volume
        except ZeroDivisionError:
            return "Volume cannot be zero"

# 3. API Gravity
class APIGravity(PetroleumFormula):
    def __init__(self, sg):
        self.sg = sg  # specific gravity

    def calculate(self):
        try:
            return (141.5 / self.sg) - 131.5
        except Exception as e:
            return f"Error: {e}"

# 4. Hydrostatic Pressure = 0.052 * MudWeight * TrueVerticalDepth
class HydrostaticPressure(PetroleumFormula):
    def __init__(self, mud_weight, tvd):
        self.mud_weight = mud_weight
        self.tvd = tvd

    def calculate(self):
        return 0.052 * self.mud_weight * self.tvd

# 5. Oil Formation Volume Factor (Bo) - simple model
class OilFVF(PetroleumFormula):
    def __init__(self, Vo, Vsc):
        self.Vo = Vo  # volume at reservoir
        self.Vsc = Vsc  # volume at surface

    def calculate(self):
        try:
            return self.Vo / self.Vsc
        except ZeroDivisionError:
            return "Surface volume cannot be zero"

# 6. Gas Formation Volume Factor (Bg)
class GasFVF(PetroleumFormula):
    def __init__(self, P, T, Z, R=10.73):
        self.P = P
        self.T = T
        self.Z = Z
        self.R = R

    def calculate(self):
        try:
            return (0.0283 * self.Z * self.T) / self.P
        except ZeroDivisionError:
            return "Pressure cannot be zero"

# Demonstrating Polymorphism
formulas = [
    IdealGasLaw(P=10, V=2, n=1),
    Density(50, 10),
    APIGravity(0.85),
    HydrostaticPressure(12, 5000),
    OilFVF(150, 10),
    GasFVF(1500, 520, 0.9)
]

for f in formulas:
    print(f"{f.__class__.__name__}: {f.calculate()}")
