Name =input("Please type your name :")
Number= int(input("Type any number :")) 
if Number % 2 == 0:
    print("Your number is even", ' '+Name)
else:
    print("Your number is odd", ' ' +Name)
print(" Next lets go to multiplication table" , ' ' +Name)   
    
    
    
    
    
    ### MULTIPLICATION TIMETABLE
H = int(input("Darling please enter any number and I will give you its multiplication table: "))
print(f"\nTHIS IS YOUR MULTIPLICATION TABLE")
for m in range(1,13):
        print(f"{H} * {m} = {H * m}")
print( "Darling and this is your multiplication timetable!!, Goodluck and see you next time")