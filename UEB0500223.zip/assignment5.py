# GUESSING GAME
import random


H = random.randint(1,10)
print("Welcome to my Guessing Game!")
print("I have choosen a number between 1 and 10. Can you guess it?")
attempts = 0
max_attempts = 5
while attempts < max_attempts:
    k = int(input("Enter your guess:"))
    attempts += 1

    if k == H:
        print("Good! You are right")
        break
    elif k > H:
        print("Owwwh, That was too high")
    else:
        print("Owwwh!!! That was too low")
if attempts >= max_attempts and k != H:
    print(f"You attempted 5 times and failed to guess the number. The correct number was {H}")