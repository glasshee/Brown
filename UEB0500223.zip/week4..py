import string
import math

def task1():
    try:
        s = "Hello"
        print(s.lower())
        s = "here"
        print(s.lower())
        s = "LOVELY"
        print(s.lower())
    except Exception as e:
        print(f"Task 1 Error: {e}")

def task2():
    try:
        s = "HeLLo WoRLd"
        new_s = ''
        for i in range(len(s)):
            if s[i].isupper():
                new_s += s[i].lower()
            elif s[i].islower():
                new_s += s[i].upper()
            else:
                new_s += s[i]
        print(new_s)
    except Exception as e:
        print(f"Task 2 Error: {e}")

def task3():
    try:
        s = "HelloWorld"
        result = ''.join([c for c in s if not c.isupper()])
        print(result)
    except Exception as e:
        print(f"Task 3 Error: {e}")

def task4():
    try:
        s = "EngiNEEr"
        upper_count = sum(1 for c in s if c.isupper())
        lower_count = sum(1 for c in s if c.islower())
        print(f"Uppercase: {upper_count}, Lowercase: {lower_count}")
    except Exception as e:
        print(f"Task 4 Error: {e}")

def task5():
    try:
        s = "Data-Driven@2025!"
        result = ''.join([c for c in s if c.isalpha()])
        print(result)
    except Exception as e:
        print(f"Task 5 Error: {e}")

def task6():
    try:
        a, b, c = 3, 4, 5
        sides = [a, b, c]
        s_ = sum(sides) / 2
        area = math.sqrt(s_ * (s_ - a) * (s_ - b) * (s_ - c))
        print(area)
    except Exception as e:
        print(f"Task 6 Error: {e}")

def task7():
    try:
        names = ["Alice", "Bob", "Charlie", "David"]
        print("Name Table:")
        for name in names:
            print(name.ljust(10), name.rjust(10), name.center(15))
    except Exception as e:
        print(f"Task 7 Error: {e}")

def task8():
    try:
        s = "   Hello, World!    "
        s = s.strip()
        s = ''.join([c for c in s if c not in string.punctuation])
        s = s.replace(' ', '')
        print(s)
    except Exception as e:
        print(f"Task 8 Error: {e}")

if _name_ == "_main_":
    task1()
    task2()
    task3()
    task4()
    task5()
    task6()
    task7()
    task8()