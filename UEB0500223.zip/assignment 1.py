# -----------------------------------------------------------------
# Python Programming Tasks 
# Author: [Hygenius Mensah]
# Date: [17th July 2025]
# -----------------------------------------------------------------

# -----------------------------------------------------------------
# Task 1: Variable Creation
# ------------------------------------------------------------------

# Creating variables of different data types
integer_value = 42
float_value = 19.99
string_value = "Will you marry me???"
boolean_value = False

# Displaying each variable with its type
print("Task 1 Output:")
print(f"{integer_value} is from {type(integer_value)}")
print(f"{float_value} is from {type(float_value)}")
print(f'"{string_value}" is from {type(string_value)}')
print(f"{boolean_value} is from {type(boolean_value)}")
print("\n")  # newline for spacing

# ----------------------------------------------------------------------
# Task 2: Type Conversion
# -----------------------------------------------------------------------

print("Task 2 Output:")

# a. Convert float to integer
converted_int = int(109.99)
print(f"My converted int: {converted_int}, Type: {type(converted_int)}")

# b. Convert integer to string
converted_str = str(670)
print(f"My converted str: '{converted_str}', Type: {type(converted_str)}")

# c. Convert string to float
converted_float = float("500")
print(f"My converted float: {converted_float}, Type: {type(converted_float)}")
print("\n")

# ------------------------------------------------------------------------------
# Task 3: Greeting User
# ------------------------------------------------------------------------------

print("Task 3 Output:")
first_name = input("What is your first name: ")
last_name = input("What is your last name: ")
print(f"Pleassure meeting you, {last_name} {first_name}!\n")

# -----------------------------------------------------------------------------
# Task 4: Error Fixing
# ------------------------------------------------------------------------------

print("Task 4 Output:")
age = 20

# Fixed: converting integer to string before concatenation
print("You are " + str(age) + " years old.")

print("\n")

# ---------------------------------------------------------------------------------
# Task 5: Repeat Word
# ----------------------------------------------------------------------------------

print("Task 5 Output:")
fav_word = input("What is your favourite word? ")
repeat_times = int(input("How many times should I repeat it? "))
print((fav_word + " ") * repeat_times)
print("\n")

# ----------------------------
# Task 6: Match the Error
# ----------------------------

print("Task 6 Output:")
print("Error Matching:")
print("a. print(\"Hello      → C. SyntaxError")
print("b. int(\"abc\")        → A. ValueError")
print("c. \"age\" + 10        → B. TypeError")
